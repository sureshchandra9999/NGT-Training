public class Largest {

    public static void main(String[] args) {
        int[] numArray = { 23, 34, 500, 33, 55, 43, 5, 66 };
        double largest = numArray[0];

        for (int num: numArray) {
            if(largest < num)
                largest = num;
        }

        System.out.format("Largest element = ", largest);
    }
}