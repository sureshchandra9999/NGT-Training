package Javapkg;

public class If_Else_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
		if(a>b)
	      System.out.println("A is greater");
		else
		  System.out.println("B is greater");
	}

}
