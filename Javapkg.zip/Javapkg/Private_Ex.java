package Javapkg;
class A
{
	private int a=8;
}
public class Private_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A obj=new A();
		System.out.println(obj.a);
	}

}
