package Javapkg;

public class Ternery_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10;
int b=20;
String c=(a<b)?"A is lesser":"B is lesser";
System.out.println(c);
	}

}
