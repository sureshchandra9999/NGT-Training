package Javapkg;

public class If_else_if_ladder_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=9;
if(a%2==0) {
	System.out.println("a is multiple of 2");
}
else if(a%3==0)
{
	System.out.println("a is multiple of 3");
}
else if(a%5==0)
	{
	System.out.println("a is multiple of 5");
	}
else
	{
	System.out.println("a is an integer");
	}
	}

}
