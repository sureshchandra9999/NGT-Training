package Javapkg;

public class TypeConversion_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i=100;
long l=i;
long a=1000000;
int b=(int) a;
float f=3.14f;
int g=(int) f;
System.out.println(l);
System.out.println(b);
System.out.println(g);
	}

}
