package Javapkg;

public class IncrDecr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=19;
System.out.println("Value of a is"+ a);
System.out.println("Value of a++ is"+ a++);
System.out.println("Value of ++a is"+ ++a);
System.out.println("Value 0f a-- is"+ a--);
System.out.println("Value of --a is"+ --a);
System.out.println (a++ + ++a);
	}

}
