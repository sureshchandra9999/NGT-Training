package Javapkg;
class A
{
	int a=8;
}
public class Default_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
A obj=new A();
System.out.println(obj.a);
	}

}
