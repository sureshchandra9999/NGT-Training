package Javapkg;

public class LogicalOP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
boolean a=true;
int b=7;
int c=9;
System.out.println(!a);
boolean B=b>10;
boolean C=c<10;
System.out.println(B && C);
System.out.println(B || C);
	}

}
