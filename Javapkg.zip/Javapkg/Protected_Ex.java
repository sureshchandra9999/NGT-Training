package Javapkg;
class C
{
	int h=19;
}
public class Protected_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C obj=new C();
		B obj1=new B();
		System.out.println(obj1.b);
		System.out.println(obj.h);
	}

}
