package Javapkg;
class B
{
	public int b=10;
}
public class Public_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B obj=new B();
		System.out.println(obj.b);
	}

}
