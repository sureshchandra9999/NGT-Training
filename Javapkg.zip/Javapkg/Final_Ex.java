package Javapkg;

public class Final_Ex {
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int r=6;
        System.out.println("Area :"+3.14*r*r);

	}

}
