package Javapkg;

public class Do_While_Loop_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i=10;
do
{
	System.out.println(i);
	i--;
}while(i>=1);
	}

}
