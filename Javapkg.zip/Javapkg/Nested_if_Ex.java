package Javapkg;

public class Nested_if_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=20;
int b=10;
int c=50;
if(a>b)
{
	if(a>c)
	{
		System.out.println("a is greater");
		
	}
	else
	{
		System.out.println("c is greater");
	}
}
else
	System.out.println("b is greater");
	}

}
