package Javapkg;

public class If_Ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      int a=10;
      if(a%5==0)
      {
    	  System.out.println("A is multiple of 5");
      }
      System.out.println("A is an integer");
	}

}
