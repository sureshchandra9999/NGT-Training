package basicsofJava;
import accessModifiers.*;


public class InheritedProtected extends UseOfProtected {
	public static void main(String[] args) {
		UseOfProtected.cube(3.4);
	}
	

}
