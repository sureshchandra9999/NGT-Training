package basicsofJava;

public class WhileLoop {

	public static void main(String[] args) {
		int a= 100;
		while(a!=0) {
		System.out.print(a+" ");
				a--;
		}
		
	}

}
