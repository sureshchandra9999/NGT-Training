package polymorphism;

public class MethodOverriding {

	void display(){
		System.out.println("display simple method");
			}
	
	
	public static void main(String[] args) {
		 MethodOverriding obj= new MethodOverriding();
		 obj.display();
		
}
}
