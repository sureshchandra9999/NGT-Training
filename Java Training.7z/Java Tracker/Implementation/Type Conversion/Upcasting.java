package typeConversion;

public class Upcasting 
{

	public static void main(String[] args) {

		double d= 3.4;
		System.out.println(d);
		
		long l=(long)d;
		System.out.println(l);
		
		float f= (float)d;
		System.out.println(l);
		
		int a=(int)d;
		System.out.println(a);
	}

}
