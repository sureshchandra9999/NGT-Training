package typeConversion;

public class Downcasting {
 
	
	public static void main(String[] args)
	 {

		int d = 23;
		System.out.println("int value "+d);
		long l= d;
		System.out.println("long value "+d);
		float f= d;
		System.out.println("float value  "+d);
		double e=d;
		System.out.println("double value "+d);

		
	}

}
