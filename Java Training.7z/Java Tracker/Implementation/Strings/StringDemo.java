package stringDemo;

public class StringDemo {
public static void main(String[] args)
 {
	String str= new String("   Hello World !");
	System.out.println(str);
	
	String str1= "Batkiri Goutham Kumar";
	System.out.println(str1);
	
	System.out.println(str.concat(str1)); 
	System.out.println(str.trim()); 
	System.out.println(str.endsWith("!"));
	System.out.println(str.substring(4));
	System.out.println(str1.length());
	
 }
}
