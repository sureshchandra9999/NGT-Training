package stringDemo;

public class StringBufferDemo {
	public static void main(String[] args) {
	
StringBuffer sf= new StringBuffer("Goutham");
 
System.out.println(sf.capacity());
System.out.println(sf.charAt(3));
System.out.println(sf.codePointAt(0));    
System.out.println(sf.substring(0, 2));   
System.out.println(sf.length());

System.out.println(sf.reverse()); 

	}

}
