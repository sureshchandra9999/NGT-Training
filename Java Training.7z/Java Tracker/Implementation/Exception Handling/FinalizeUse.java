package exceptionHandling;

public class FinalizeUse {
	 final int a=22;
	void divide(){
		int b=a/22;
		throw new ArithmeticException("Exception caught");
	}
	
	
 public static void main(String[] args) throws Throwable {
	 FinalizeUse fs= new FinalizeUse();
	 fs.divide();
}
}
