package abstractionAndEncapsulation;
abstract class Shape
{
	abstract double area();
}
class Square extends Shape
{
	double side=10;
	double area() {
		return side*side;
	}
}
class Circle extends Shape{
	double r=5;
	double area() {
		return 3.14*r*r;
	}
}

public class AbstractDemo {
 public static void main(String[] args) {
	Square s= new Square();
	System.out.println("area of square = "+s.area()+" sq. unit");
	Circle c= new Circle();
	System.out.println("area of Circle = "+c.area()+" sq. unit");
}
}
